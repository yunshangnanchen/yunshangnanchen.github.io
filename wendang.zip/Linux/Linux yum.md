# Linux yum 命令

**一、概述**

yum（Yellow dog Updater, Modified）是一个在 Fedora 和 RedHat 以及 SUSE 中的 Shell 前端软件包管理器。基于 RPM 包管理，能够从指定的服务器自动下载 RPM 包并且安装，可以自动处理依赖性关系，并且一次安装所有依赖的软件包，无须繁琐地一次次下载、安装。yum 提供了查找、安装、删除某一个、一组甚至全部软件包的命令，而且命令简洁而又好记。

**二、语法**

`yum [options] [command] [package...]`

其中，`options`是可选的选项，包括 `-h`（帮助），`-y`（当安装过程提示选择全部为 "yes"），`-q`（不显示安装的过程）等等；`command`是要进行的操作；`package`是安装的包名。

**三、常用命令**

1. 列出所有可更新的软件清单命令：`yum check-update`
2. 更新所有软件命令：`yum update`
3. 仅安装指定的软件命令：`yum install <package_name>`
4. 仅更新指定的软件命令：`yum update <package_name>`
5. 列出所有可安装的软件清单命令：`yum list`
6. 删除软件包命令：`yum remove <package_name>`
7. 查找软件包命令：`yum search <keyword>`
8. 清除缓存命令：
   - `yum clean packages`：清除缓存目录下的软件包。
   - `yum clean headers`：清除缓存目录下的 headers。
   - `yum clean oldheaders`：清除缓存目录下旧的 headers。
   - `yum clean, yum clean all (= yum clean packages; yum clean oldheaders)`：清除缓存目录下的软件包及旧的 headers。

**四、实例**

1. 安装`pam-devel`：

   ```
   [root@www ~]# yum install pam-devel
   Setting up Install Process
   Parsing package install arguments
   Resolving Dependencies  <==先检查软件的属性相依问题
   --> Running transaction check
   ---> Package pam-devel.i386 0:0.99.6.2-4.el5 set to be updated
   --> Processing Dependency: pam = 0.99.6.2-4.el5 for package: pam-devel
   --> Running transaction check
   ---> Package pam.i386 0:0.99.6.2-4.el5 set to be updated
   filelists.xml.gz          100% |=========================| 1.6 MB    00:05
   filelists.xml.gz          100% |=========================| 138 kB    00:00
   -> Finished Dependency Resolution
   ……(省略)
   ```

2. 移除`pam-devel`：

   ```
   [root@www ~]# yum remove pam-devel
   Setting up Remove Process
   Resolving Dependencies  <==同样的，先解决属性相依的问题
   --> Running transaction check
   ---> Package pam-devel.i386 0:0.99.6.2-4.el5 set to be erased
   --> Finished Dependency Resolution

   Dependencies Resolved

   =============================================================================
   Package                 Arch       Version          Repository        Size
   =============================================================================
   Removing:
   pam-devel               i386       0.99.6.2-4.el5   installed         495 k

   Transaction Summary
   =============================================================================
   Install      0 Package(s)
   Update       0 Package(s)
   Remove       1 Package(s)  <==还好，并没有属性相依的问题，单纯移除一个软件

   Is this ok [y/N]: y
   Downloading Packages:
   Running rpm_check_debug
   Running Transaction Test
   Finished Transaction Test
   Transaction Test Succeeded
   Running Transaction
     Erasing   : pam-devel                    ######################### [1/1]

   Removed: pam-devel.i386 0:0.99.6.2-4.el5
   Complete!
   ```

3. 利用 yum 的功能，找出以`pam`为开头的软件名称有哪些？

   ```
   [root@www ~]# yum list pam*
   Installed Packages
   pam.i386                  0.99.6.2-3.27.el5      installed
   pam_ccreds.i386           3-5                    installed
   pam_krb5.i386             2.2.14-1               installed
   pam_passwdqc.i386         1.0.2-1.2.2            installed
   pam_pkcs11.i386           0.5.3-23               installed
   pam_smb.i386              1.1.7-7.2.1            installed
   Available Packages <==底下则是『可升级』的或『未安装』的
   pam.i386                  0.99.6.2-4.el5         base
   pam-devel.i386            0.99.6.2-4.el5         base
   pam_krb5.i386             2.2.14-10              base
   ```

**五、国内 yum 源**

网易（163）yum 源是国内较好的 yum 源之一，无论是速度还是软件版本，都非常的不错。

将 yum 源设置为 163 yum，可以提升软件包安装和更新的速度，同时避免一些常见软件版本无法找到。

安装步骤：
1. 首先备份`/etc/yum.repos.d/CentOS-Base.repo`：

   `mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.backup`

2. 下载对应版本 repo 文件，放入`/etc/yum.repos.d/`（操作前请做好相应备份）：

   - CentOS5：http://mirrors.163.com/.help/CentOS5-Base-163.repo
   - CentOS6：http://mirrors.163.com/.help/CentOS6-Base-163.repo
   - CentOS7：http://mirrors.163.com/.help/CentOS7-Base-163.repo

   例如：`wget http://mirrors.163.com/.help/CentOS6-Base-163.repo`，然后`mv CentOS6-Base-163.repo CentOS-Base.repo`。

3. 运行以下命令生成缓存：

   `yum clean all`，`yum makecache`

除了网易之外，国内还有其他不错的 yum 源，比如中科大和搜狐。

中科大的 yum 源，安装方法查看：https://lug.ustc.edu.cn/wiki/mirrors/help/centos。

sohu 的 yum 源安装方法查看: http://mirrors.sohu.com/help/centos.html。

阿里云的源：https://developer.aliyun.com/mirror/centos。

总之，yum 命令为 Fedora、RedHat 和 SUSE 等系统的软件包管理提供了便捷的方式，通过使用国内的 yum 源可以提高软件包安装和更新的速度。